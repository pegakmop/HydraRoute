const fs = require('fs');
const os = require('os');
const path = require('path');
const cors = require('cors');
const express = require('express');
const session = require('express-session');
const { exec, execSync } = require('child_process');

const app = express();
const filePath = '/opt/etc/AdGuardHome/domain.conf';
const PORT = 2000;

// Инициализация сессии
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Установите secure: true, если используете HTTPS
}));

// Middleware для проверки авторизации
function checkAuth(req, res, next) {
    if (req.path === '/login' || req.session.isAuthenticated) {
        return next();
    }
    res.redirect('/login');
}

// Применение middleware ко всем маршрутам, кроме /login
app.use(checkAuth);

app.use(cors());
app.use(express.static('/opt/etc/HydraRoute/public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Функция для декодирования base64 с использованием системной утилиты
function decodeBase64(encoded) {
    return execSync(`echo "${encoded}" | base64 -d`).toString().trim();
}

// Маршрут для отображения страницы авторизации
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// Маршрут для обработки данных авторизации
app.post('/login', express.urlencoded({ extended: true }), (req, res) => {
    const { password_key } = req.body;

    // Чтение зашифрованного пароля из файла
    const encryptedPassword = fs.readFileSync('/opt/etc/HydraRoute/public/login.scrt', 'utf8').trim();
    const decodedPassword = decodeBase64(encryptedPassword);

    if (password_key === decodedPassword) {
        req.session.isAuthenticated = true;
        res.redirect('/');
    } else {
        res.status(401).send('Неверный пароль');
    }
});

// Маршрут для выхода из системы
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Ошибка при выходе из системы');
        }
        res.redirect('/login');
    });
});

app.post('/change-password', (req, res) => {
    const { currentPassword, newPassword } = req.body;

    // Чтение текущего пароля из файла
    const encryptedPassword = fs.readFileSync('/opt/etc/HydraRoute/public/login.scrt', 'utf8').trim();
    const decodedPassword = decodeBase64(encryptedPassword);

    if (currentPassword !== decodedPassword) {
        return res.status(401).json({ success: false, error: 'Неверный текущий пароль.' });
    }

    // Кодирование нового пароля в base64
    const encodedNewPassword = execSync(`echo -n "${newPassword}" | base64`).toString().trim();

    // Запись нового пароля в файл
    fs.writeFileSync('/opt/etc/HydraRoute/public/login.scrt', encodedNewPassword, 'utf8');

    res.json({ success: true });
});

// Основной маршрут
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/load-services', async (req, res) => {
    try {
        const response = await fetch('https://github.com/Ground-Zerro/DomainMapper/raw/refs/heads/main/platformdb');
        const text = await response.text();
        const lines = text.split(/\r?\n/).filter(Boolean);
        const services = lines.map(line => {
            const separatorIndex = line.indexOf(': ');
            if (separatorIndex !== -1) {
                const name = line.substring(0, separatorIndex).trim();
                const url = line.substring(separatorIndex + 2).trim();
                return { name, url };
            }
            return null;
        }).filter(service => service !== null);

        res.json(services);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка загрузки списка сервисов.' });
    }
});

function parseIpsetDomains() {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const lines = fileContent.split('\n').filter(line => line.trim() !== '');

    const domains = new Set();

    const getRootDomain = (domain) => {
        const parts = domain.split('.');
        return parts.length > 2 ? parts.slice(-2).join('.') : domain;
    };

    lines.forEach(line => {
        if (!line.startsWith('##') && !line.startsWith('#')) {
            const index = line.lastIndexOf('/');
            if (index !== -1) {
                const domainList = line.substring(0, index).trim();
                domainList.split(',').forEach(domain => {
                    const normalizedDomain = getRootDomain(domain.trim());
                    domains.add(normalizedDomain);
                });
            }
        }
    });

    return domains;
}

app.post('/load-from-github', async (req, res) => {
    const { services } = req.body;

    if (!services || !services.length) {
        return res.status(400).send('Нет выбранных сервисов для загрузки.');
    }

    try {
        const allDomains = new Set();
        const existingDomains = parseIpsetDomains();

        const removeBOM = (content) => {
            return content.startsWith('\uFEFF') ? content.slice(1) : content;
        };

        const getRootDomain = (domain) => {
            const parts = domain.split('.');
            return parts.length > 2 ? parts.slice(-2).join('.') : domain;
        };

        const consolidateDomains = (domains) => {
            const rootMap = new Map();
            
            domains.forEach(domain => {
                const rootDomain = getRootDomain(domain);
                if (!rootMap.has(rootDomain)) {
                    rootMap.set(rootDomain, new Set());
                }
                rootMap.get(rootDomain).add(domain);
            });

            return Array.from(rootMap.entries()).map(([root, subs]) =>
                subs.size > 1 ? root : Array.from(subs)[0]
            );
        };

        for (const serviceUrl of services) {
            const response = await fetch(serviceUrl);
            let content = await response.text();
            content = removeBOM(content);
            content.split(/\r?\n/)
                   .map(line => line.trim())
                   .filter(Boolean)
                   .forEach(domain => {
                       const normalizedDomain = getRootDomain(domain); // Нормализуем домен перед проверкой
                       if (!existingDomains.has(normalizedDomain)) { // Исключаем домены, которые уже есть в файле
                           allDomains.add(domain);
                       }
                   });
        }

        const consolidatedDomains = consolidateDomains(Array.from(allDomains));
        res.json({ domains: consolidatedDomains });
    } catch (error) {
        res.status(500).send('Ошибка обработки сервисов.');
    }
});

function parseConfig() {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const lines = fileContent.split('\n').filter(line => line.trim() !== '');

    const parsedData = { hr1: [], hr2: [], hr3: [] };
    let currentDescription = '';

    lines.forEach(line => {
        if (line.startsWith('##')) {
            currentDescription = line.substring(2).trim();
        } else {
            let active = true;
            if (line.startsWith('#')) {
                active = false;
                line = line.substring(1);
            }

            const index = line.lastIndexOf('/hr');
            if (index === -1) return;

            const domains = line.substring(0, index).trim();
            const ipset = line.substring(index + 1);

            if (parsedData[ipset]) {
                parsedData[ipset].push({ domains, active, description: currentDescription });
                currentDescription = '';
            }
        }
    });

    return parsedData;
}

app.get('/config', (req, res) => {
    try {
        res.json(parseConfig());
    } catch (error) {
        res.status(500).send('Ошибка загрузки файла');
    }
});

app.post('/save', (req, res) => {
    try {
        const data = req.body;
        let lines = [];

        Object.keys(data).forEach(ipset => {
            data[ipset].forEach(entry => {
                if (entry.description && entry.description.trim() !== '') {
                    lines.push(`##${entry.description}`);
                }
                let line = entry.domains;
                if (!entry.active) {
                    line = '#' + line;
                }
                line += `/${ipset}`;
                lines.push(line);
            });
        });

        fs.writeFileSync(filePath, lines.join('\n'), 'utf8');

        try {
            execSync("agh stop");

            ['hr1', 'hr2', 'hr3'].forEach(ipset => execSync(`ipset flush ${ipset}`));

            execSync("agh start");

            res.json({ success: true });
        } catch (execError) {
            res.status(500).json({ success: false, error: 'Ошибка при выполнении команд ipset или AGH' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: 'Ошибка сохранения' });
    }
});

app.get('/interfaces', (req, res) => {
    try {
        const policyNames = ["HydraRoute1st", "HydraRoute2nd", "HydraRoute3rd"];

        const policiesOutput = execSync('curl -kfsS localhost:79/rci/show/ip/policy/').toString();
        const policyData = JSON.parse(policiesOutput);

        const interfacesOutput = execSync('curl -kfsS localhost:79/rci/show/interface/').toString();
        const interfaceData = JSON.parse(interfacesOutput);
        const interfacesArray = Object.keys(interfaceData).map(key => interfaceData[key]);

        const interfaces = policyNames.map(policy => {
            const route = policyData[policy] && policyData[policy].route4 && policyData[policy].route4.route ?
                policyData[policy].route4.route.find(r => r.destination === "0.0.0.0/0") : null;

            const interfaceId = route ? route.interface : "Null";

            if (interfaceId === "Null") {
                return "Null";
            }

            const interfaceInfo = interfacesArray.find(iface => iface.id === interfaceId);

            return interfaceInfo ? interfaceInfo.description : "Null";
        });

        res.json(interfaces);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка получения интерфейсов', details: error.message });
    }
});

app.get('/br0ip', (req, res) => {
    res.json({ ip: br0IP });
});

app.get('/agh-status', (req, res) => {
    exec("/opt/etc/init.d/S99adguardhome status", (error, stdout, stderr) => {
        if (error || !stdout.includes("alive")) {
            return res.status(500).send('Остановлен');
        }

        res.send('Запущен и работает');
    });
});

app.post('/agh-restart', (req, res) => {
    try {
		try {
            execSync("agh stop");
        } catch (stopError) {
            console.error("Ошибка при остановке AdGuardHome:", stopError.message);
        }

        ['hr1', 'hr2', 'hr3'].forEach(ipset => execSync(`ipset flush ${ipset}`));

        execSync("agh start");

        res.send('AdGuardHome перезапущен');
    } catch (execError) {
        res.status(500).json({ success: false, error: 'Ошибка перезапуска AdGuardHome' });
    }
});

function getBr0IP() {
    const interfaces = os.networkInterfaces();
    if (interfaces.br0) {
        const br0 = interfaces.br0.find(addr => addr.family === 'IPv4' && !addr.internal);
        return br0 ? br0.address : null;
    }
    return null;
}

const br0IP = getBr0IP();
if (!br0IP) {
    process.exit(1);
}

app.listen(PORT, br0IP, () => {
    console.log(`Сервер HR запущен на http://${br0IP}:${PORT}`);
});
