const fs = require('fs');
const os = require('os');
const path = require('path');
const cors = require('cors');
const express = require('express');
const app = express();
const { exec } = require('child_process');
const { execSync } = require('child_process');
const filePath = '/opt/etc/AdGuardHome/domain.conf';
const PORT = 2000;

app.use(cors());
app.use(express.static('/opt/etc/HydraRoute/public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

function parseConfig() {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const lines = fileContent.split('\n').filter(line => line.trim() !== '');

    const parsedData = { hr1: [], hr2: [], hr3: [] };
    let currentDescription = '';

    lines.forEach(line => {
        if (line.startsWith('##')) {
            currentDescription = line.substring(2).trim();
        } else {
            let active = true;
            if (line.startsWith('#')) {
                active = false;
                line = line.substring(1);
            }

            const index = line.lastIndexOf('/hr');
            if (index === -1) return;

            const domains = line.substring(0, index).trim();
            const ipset = line.substring(index + 1);

            if (parsedData[ipset]) {
                parsedData[ipset].push({ domains, active, description: currentDescription });
                currentDescription = '';
            }
        }
    });

    return parsedData;
}

app.get('/config', (req, res) => {
    try {
        res.json(parseConfig());
    } catch (error) {
        res.status(500).send('Ошибка загрузки файла');
    }
});

app.post('/save', (req, res) => {
    try {
        const data = req.body;
        let lines = [];

        Object.keys(data).forEach(ipset => {
            data[ipset].forEach(entry => {
                if (entry.description && entry.description.trim() !== '') {
                    lines.push(`##${entry.description}`);
                }
                let line = entry.domains;
                if (!entry.active) {
                    line = '#' + line;
                }
                line += `/${ipset}`;
                lines.push(line);
            });
        });

        fs.writeFileSync(filePath, lines.join('\n'), 'utf8');

        try {
            execSync("agh stop");

            ['hr1', 'hr2', 'hr3'].forEach(ipset => execSync(`ipset flush ${ipset}`));

            execSync("agh start");

            res.json({ success: true });
        } catch (execError) {
            res.status(500).json({ success: false, error: 'Ошибка при выполнении команд ipset или AGH' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: 'Ошибка сохранения' });
    }
});

app.get('/interfaces', (req, res) => {
    try {
        const policyNames = ["HydraRoute1st", "HydraRoute2nd", "HydraRoute3rd"];

        const policiesOutput = execSync('curl -kfsS localhost:79/rci/show/ip/policy/').toString();
        const policyData = JSON.parse(policiesOutput);

        const interfacesOutput = execSync('curl -kfsS localhost:79/rci/show/interface/').toString();
        const interfaceData = JSON.parse(interfacesOutput);
        const interfacesArray = Object.keys(interfaceData).map(key => interfaceData[key]);

        const interfaces = policyNames.map(policy => {
            const route = policyData[policy] && policyData[policy].route4 && policyData[policy].route4.route ?
                policyData[policy].route4.route.find(r => r.destination === "0.0.0.0/0") : null;

            const interfaceId = route ? route.interface : "Null";

            if (interfaceId === "Null") {
                return "Null";
            }

            const interfaceInfo = interfacesArray.find(iface => iface.id === interfaceId);

            return interfaceInfo ? interfaceInfo.description : "Null";
        });

        res.json(interfaces);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка получения интерфейсов', details: error.message });
    }
});

app.get('/br0ip', (req, res) => {
    res.json({ ip: br0IP });
});

app.get('/agh-status', (req, res) => {
    exec("/opt/etc/init.d/S99adguardhome status", (error, stdout, stderr) => {
        if (error || !stdout.includes("alive")) {
            return res.status(500).send('Остановлен');
        }

        res.send('Запущен и работает');
    });
});

app.post('/agh-restart', (req, res) => {
    try {
        execSync("agh stop");

        ['hr1', 'hr2', 'hr3'].forEach(ipset => execSync(`ipset flush ${ipset}`));

        execSync("agh start");

        res.send('AdGuardHome перезапущен');
    } catch (execError) {
        res.status(500).json({ success: false, error: 'Ошибка перезапуска AdGuardHome' });
    }
});

function getBr0IP() {
    const interfaces = os.networkInterfaces();
    if (interfaces.br0) {
        const br0 = interfaces.br0.find(addr => addr.family === 'IPv4' && !addr.internal);
        return br0 ? br0.address : null;
    }
    return null;
}

const br0IP = getBr0IP();
if (!br0IP) {
    process.exit(1);
}

app.listen(PORT, br0IP, () => {
    console.log(`Сервер HR запущен на http://${br0IP}:${PORT}`);
});
